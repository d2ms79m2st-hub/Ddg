const K='bak.db.v1',C='bak.cart.v1';
export const STATUS=['جديد','قيد التجهيز','تم الشحن','تم التسليم','ملغي'];
const seed=()=>({
 cats:[{id:'oud',name:'أعواد فاخرة'},{id:'gifts',name:'عطور للإهداء'},{id:'saffron',name:'الزعفران'}],
 products:[
  {id:'demo1',name:'منتج تجريبي — عود',cat:'oud',price:450,discount:0,stock:10,img:'',featured:true,active:true,desc:'بيانات تجريبية. عدّلها من لوحة الإدارة.',demo:true},
  {id:'demo2',name:'منتج تجريبي — عطر',cat:'gifts',price:300,discount:15,stock:5,img:'',featured:true,active:true,desc:'بيانات تجريبية. عدّلها من لوحة الإدارة.',demo:true},
  {id:'demo3',name:'منتج تجريبي — زعفران',cat:'saffron',price:120,discount:0,stock:0,img:'',featured:false,active:true,desc:'بيانات تجريبية. عدّلها من لوحة الإدارة.',demo:true}],
 orders:[],
 settings:{pass:'admin123',promo:'',wa:'966533155202'}});
let _d;try{_d=JSON.parse(localStorage.getItem(K))}catch{}
export const db=_d||seed();
export const save=()=>localStorage.setItem(K,JSON.stringify(db));
export const final=p=>Math.round(p.price*(1-(p.discount||0)/100));
export const money=n=>Number(n).toLocaleString('en')+' ر.س';
export const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const getCart=()=>{try{return JSON.parse(localStorage.getItem(C))||[]}catch{return[]}};
export const setCart=c=>localStorage.setItem(C,JSON.stringify(c));
export const uid=()=>Math.random().toString(36).slice(2,9);
