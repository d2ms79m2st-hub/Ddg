import {db,save,final,money,esc,getCart,setCart,STATUS} from './store.js';
const $=(s,r=document)=>r.querySelector(s),app=$('#app'),RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
const live=()=>db.products.filter(p=>p.active!==false);
const art=p=>p.img?`<img src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy">`:`<div class="ph"><span>${esc(p.name)}</span></div>`;
const tile=p=>`<a class="tile" href="#/p/${p.id}"><div class="art">${art(p)}${p.stock<=0?'<i class="tag">نفد المخزون</i>':p.discount?`<i class="tag gold">خصم ${p.discount}%</i>`:''}</div><h3>${esc(p.name)}</h3><p class="pr">${p.discount?`<s>${money(p.price)}</s> `:''}${money(final(p))}</p></a>`;
const grid=l=>l.length?`<div class="grid">${l.map(tile).join('')}</div>`:'<p class="empty">لا توجد منتجات هنا بعد.</p>';
let off=()=>{};
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2400)}

/* ---------- pages ---------- */
function home(){
 const feat=live().filter(p=>p.featured),offers=live().filter(p=>p.discount>0);
 const words='عودٌ يُختار بعناية، وعطرٌ يُهدى بفخر.'.split(' ').map(w=>`<span>${w}</span>`).join(' ');
 app.innerHTML=`
 <section class="hero"><svg class="smoke" viewBox="0 0 400 700" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
  <path d="M200 700C140 600 280 540 210 440S150 280 230 190 190 40 215 0"/><path d="M170 700C110 610 240 560 180 470S120 330 190 250 160 110 180 40"/><path d="M240 700C300 600 170 560 250 450S300 300 220 210 260 60 235 0"/></svg>
  <img class="seal" src="assets/logo.png" alt="شعار بدر أبا الخيل" width="220" height="220">
  <h1>عزنا بطيبنا</h1><p class="tagl">عبقٌ يفوح</p>
  <a class="btn" href="#cats">تسوّق الآن</a></section>
 <section class="stmt" aria-label="عن بدر أبا الخيل"><p>${words}</p></section>
 <section id="cats" class="cats" aria-label="الأقسام">${db.cats.map((c,i)=>`<a class="catrow c${i%3}" href="#/c/${c.id}"><span>${esc(c.name)}</span><em>${live().filter(p=>p.cat===c.id).length} منتج</em></a>`).join('')}</section>
 ${feat.length?`<section class="wrap"><h2>مختارات</h2>${grid(feat)}</section>`:''}
 ${offers.length?`<section class="wrap offers"><h2>العروض</h2>${grid(offers)}</section>`:''}
 <section class="wrap contact"><h2>تواصل معنا</h2><div class="links">
  <a href="https://wa.me/${esc(db.settings.wa)}" target="_blank" rel="noopener">واتساب</a>
  <a href="https://instagram.com/bader_aloud" target="_blank" rel="noopener">إنستغرام</a>
  <a href="https://www.tiktok.com/@bader_aloud" target="_blank" rel="noopener">تيك توك</a>
  <a href="https://snapchat.com/t/isHYiQnt" target="_blank" rel="noopener">سناب شات</a>
  <a href="https://maps.app.goo.gl/JiouN8tVJcUNAQP17" target="_blank" rel="noopener">موقع المحل</a>
  <a href="https://baderabalkhail.com" target="_blank" rel="noopener">المتجر الرسمي</a></div></section>`;
 const s=$('.stmt'),w=[...s.querySelectorAll('span')];
 const f=()=>{if(RM)return w.forEach(x=>x.style.opacity=1);const r=s.getBoundingClientRect(),p=Math.min(1,Math.max(0,(innerHeight*.85-r.top)/(r.height+innerHeight*.3)));w.forEach((x,i)=>x.style.opacity=.18+.82*Math.min(1,Math.max(0,p*w.length*1.2-i)))};
 addEventListener('scroll',f,{passive:true});off=()=>removeEventListener('scroll',f);f();
}
function category(id){const c=db.cats.find(x=>x.id===id);if(!c)return nf();
 const sort=sessionStorage.sort||'';let l=live().filter(p=>p.cat===id);
 if(sort==='lo')l.sort((a,b)=>final(a)-final(b));if(sort==='hi')l.sort((a,b)=>final(b)-final(a));
 app.innerHTML=`<section class="wrap page"><h1>${esc(c.name)}</h1><nav class="chips" aria-label="الأقسام">${db.cats.map(x=>`<a href="#/c/${x.id}" ${x.id===id?'aria-current="page"':''}>${esc(x.name)}</a>`).join('')}</nav>
 <label class="sort">الترتيب <select id="sort"><option value="">الافتراضي</option><option value="lo" ${sort==='lo'?'selected':''}>السعر: الأقل أولاً</option><option value="hi" ${sort==='hi'?'selected':''}>السعر: الأعلى أولاً</option></select></label>${grid(l)}</section>`;
 $('#sort').onchange=e=>{sessionStorage.sort=e.target.value;category(id)}}
function search(q){q=decodeURIComponent(q).trim();const l=live().filter(p=>(p.name+p.desc).includes(q));
 app.innerHTML=`<section class="wrap page"><h1>نتائج «${esc(q)}»</h1>${grid(l)}</section>`}
function product(id){const p=db.products.find(x=>x.id===id&&x.active!==false);if(!p)return nf();const c=db.cats.find(x=>x.id===p.cat);
 app.innerHTML=`<section class="wrap pdp"><div class="art big">${art(p)}</div><div class="info"><a class="crumb" href="#/c/${p.cat}">${esc(c?.name||'')}</a><h1>${esc(p.name)}</h1>
 <p class="pr lg">${p.discount?`<s>${money(p.price)}</s> `:''}${money(final(p))}${p.discount?` <i class="tag gold">خصم ${p.discount}%</i>`:''}</p><p class="desc">${esc(p.desc)}</p>
 <p class="stock">${p.stock<=0?'نفد المخزون':p.stock<=3?`متبقي ${p.stock} فقط`:'متوفر'}</p>
 <div class="buy"><div class="qty"><button type="button" data-q="-1" aria-label="إنقاص الكمية">−</button><output id="qv">1</output><button type="button" data-q="1" aria-label="زيادة الكمية">+</button></div>
 <button class="btn" id="add" ${p.stock<=0?'disabled':''}>أضف إلى السلة</button></div></div></section>`;
 let q=1;app.onclick=e=>{const b=e.target.closest('[data-q]');if(b){q=Math.min(p.stock,Math.max(1,q+ +b.dataset.q));$('#qv').textContent=q}};
 $('#add')?.addEventListener('click',()=>{add(p.id,q);openCart()})}
function track(){app.innerHTML=`<section class="wrap page narrow"><h1>تتبع الطلب</h1><form id="tf" novalidate><label>رقم الطلب<input name="no" placeholder="BAK-XXXXXX" required></label><label>رقم الجوال<input name="ph" inputmode="tel" placeholder="05xxxxxxxx" required></label><button class="btn">تتبع</button></form><div id="tr"></div></section>`;
 $('#tf').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),o=db.orders.find(x=>x.no===f.get('no').trim().toUpperCase()&&x.phone===f.get('ph').trim());
  $('#tr').innerHTML=o?`<ol class="steps">${STATUS.slice(0,4).map((s,i)=>`<li class="${STATUS.indexOf(o.status)>=i&&o.status!=='ملغي'?'done':''}">${s}</li>`).join('')}</ol>${o.status==='ملغي'?'<p class="err">تم إلغاء هذا الطلب.</p>':''}<p>الإجمالي: ${money(o.total)}</p>`:'<p class="err">لم نجد طلباً بهذه البيانات. تأكد من الرقم وجوال الطلب.</p>'}}
function checkout(){const items=cartItems();if(!items.length){location.hash='#/';return toast('السلة فارغة')}
 app.innerHTML=`<section class="wrap page narrow"><h1>إتمام الطلب</h1><form id="cf" novalidate>
 <label>الاسم الكامل<input name="name" autocomplete="name" required></label><label>رقم الجوال<input name="phone" inputmode="tel" autocomplete="tel" placeholder="05xxxxxxxx" required></label>
 <label>المدينة<input name="city" autocomplete="address-level2" required></label><label>العنوان<textarea name="addr" rows="2" required></textarea></label><label>ملاحظات (اختياري)<textarea name="note" rows="2"></textarea></label>
 <fieldset><legend>طريقة الدفع</legend><label class="r"><input type="radio" name="pay" value="الدفع عند الاستلام" checked>الدفع عند الاستلام</label><label class="r"><input type="radio" name="pay" value="تحويل بنكي">تحويل بنكي (نؤكده معك عبر واتساب)</label><p class="hint">الدفع الإلكتروني بالبطاقة غير مفعّل: يتطلب ربط بوابة دفع.</p></fieldset>
 <p class="sum">الإجمالي: <b>${money(items.reduce((s,i)=>s+final(i.p)*i.q,0))}</b></p><p class="err" id="ce" role="alert"></p><button class="btn">تأكيد الطلب</button></form></section>`;
 $('#cf').onsubmit=e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.target)),er=[];
  if(f.name.trim().length<3)er.push('اكتب الاسم الكامل');if(!/^05\d{8}$/.test(f.phone.trim()))er.push('رقم الجوال يجب أن يبدأ بـ 05 ويتكون من 10 أرقام');if(!f.city.trim())er.push('اكتب المدينة');if(f.addr.trim().length<6)er.push('اكتب عنواناً أوضح');
  const bad=cartItems().find(i=>i.q>i.p.stock);if(bad)er.push(`الكمية المتاحة من «${bad.p.name}» ${bad.p.stock} فقط`);
  if(er.length)return $('#ce').textContent=er.join(' · ');
  const its=cartItems(),no='BAK-'+Date.now().toString(36).toUpperCase().slice(-6),total=its.reduce((s,i)=>s+final(i.p)*i.q,0);
  its.forEach(i=>i.p.stock-=i.q);db.orders.unshift({no,date:new Date().toISOString(),name:f.name.trim(),phone:f.phone.trim(),city:f.city.trim(),addr:f.addr.trim(),note:f.note.trim(),pay:f.pay,items:its.map(i=>({id:i.p.id,name:i.p.name,q:i.q,price:final(i.p)})),total,status:'جديد'});
  save();setCart([]);badge();const msg=encodeURIComponent(`طلب جديد ${no}\n`+its.map(i=>`${i.p.name} ×${i.q}`).join('\n')+`\nالإجمالي: ${total} ر.س`);
  app.innerHTML=`<section class="wrap page narrow done"><h1>تم استلام طلبك</h1><p>رقم الطلب: <b>${no}</b><br>احتفظ به مع رقم جوالك لتتبع الطلب.</p><a class="btn" href="#/track">تتبع الطلب</a> <a class="btn ghost" target="_blank" rel="noopener" href="https://wa.me/${esc(db.settings.wa)}?text=${msg}">إرسال التفاصيل عبر واتساب</a></section>`}}
const nf=()=>app.innerHTML='<section class="wrap page narrow"><h1>الصفحة غير موجودة</h1><a class="btn" href="#/">العودة للرئيسية</a></section>';

/* ---------- cart ---------- */
const cartItems=()=>getCart().map(c=>({p:db.products.find(p=>p.id===c.id),q:c.q})).filter(i=>i.p&&i.p.active!==false);
function add(id,q=1){const c=getCart(),p=db.products.find(x=>x.id===id),it=c.find(x=>x.id===id);const n=Math.min(p.stock,(it?.q||0)+q);if(it)it.q=n;else c.push({id,q:n});setCart(c);badge();toast('أُضيف إلى السلة')}
function badge(){const n=getCart().reduce((s,i)=>s+i.q,0),b=$('#cn');b.textContent=n;b.hidden=!n;drawer()}
function drawer(){const it=cartItems();$('#ci').innerHTML=it.length?it.map(i=>`<li><div class="art sm">${art(i.p)}</div><div><b>${esc(i.p.name)}</b><span>${money(final(i.p))}</span>
 <div class="qty sm"><button data-c="${i.p.id}" data-d="-1" aria-label="إنقاص">−</button><output>${i.q}</output><button data-c="${i.p.id}" data-d="1" aria-label="زيادة">+</button></div></div><button class="x" data-rm="${i.p.id}" aria-label="حذف ${esc(i.p.name)}">×</button></li>`).join(''):'<li class="empty">السلة فارغة</li>';
 $('#ct').textContent=money(it.reduce((s,i)=>s+final(i.p)*i.q,0));$('#go').hidden=!it.length}
const openCart=()=>{$('#cart').classList.add('open');document.body.classList.add('lock');$('#cart .close').focus()},closeCart=()=>{$('#cart').classList.remove('open');document.body.classList.remove('lock')};
document.addEventListener('click',e=>{const t=e.target;
 if(t.closest('#co'))openCart();if(t.closest('.close')||t.matches('.scrim'))closeCart();if(t.closest('#go'))closeCart();
 const d=t.closest('[data-c]');if(d){const c=getCart(),it=c.find(x=>x.id===d.dataset.c),p=db.products.find(x=>x.id===it.id);it.q=Math.min(p.stock,Math.max(1,it.q+ +d.dataset.d));setCart(c);badge()}
 const r=t.closest('[data-rm]');if(r){setCart(getCart().filter(x=>x.id!==r.dataset.rm));badge()}
 if(t.closest('a[href="#cats"]')){e.preventDefault();$('#cats')?.scrollIntoView({behavior:RM?'auto':'smooth'})}});
addEventListener('keydown',e=>{if(e.key==='Escape')closeCart()});
$('#sf').onsubmit=e=>{e.preventDefault();const q=$('#q').value.trim();if(q)location.hash='#/s/'+encodeURIComponent(q)};
$('#promo').textContent=db.settings.promo;$('#promo').hidden=!db.settings.promo;
$('#nav').innerHTML=db.cats.map(c=>`<a href="#/c/${c.id}">${esc(c.name)}</a>`).join('')+'<a href="#/track">تتبع الطلب</a>';

/* ---------- router ---------- */
function route(){off();off=()=>{};app.onclick=null;const[,a,b]=location.hash.slice(1).split('/');
 if(location.hash==='#cats')return;
 ({c:()=>category(b),p:()=>product(b),s:()=>search(b||''),track,checkout}[a]||home)();
 if(!location.hash.startsWith('#cats'))scrollTo(0,0);document.title='بدر أبا الخيل | العود والعطور'}
addEventListener('hashchange',route);badge();route();
