-- Run in Supabase SQL editor. NOT yet wired to the frontend (see README).
create table categories(id text primary key,name text not null,sort int default 0);
create table products(id uuid primary key default gen_random_uuid(),name text not null,category_id text references categories,price numeric not null check(price>=0),discount int default 0 check(discount between 0 and 90),stock int default 0 check(stock>=0),image_url text,description text,featured bool default false,active bool default true);
create table orders(id uuid primary key default gen_random_uuid(),order_no text unique not null,name text,phone text,city text,address text,note text,pay text,items jsonb not null,total numeric not null,status text default 'جديد',created_at timestamptz default now());
create table admins(user_id uuid primary key references auth.users);
create function is_admin() returns bool language sql security definer as $$select exists(select 1 from admins where user_id=auth.uid())$$;
alter table categories enable row level security;alter table products enable row level security;alter table orders enable row level security;alter table admins enable row level security;
create policy "public read" on categories for select using(true);
create policy "public read active" on products for select using(active or is_admin());
create policy "admin all" on categories for all using(is_admin()) with check(is_admin());
create policy "admin all" on products for all using(is_admin()) with check(is_admin());
create policy "admin all" on orders for all using(is_admin()) with check(is_admin());
-- Customers never read orders directly: tracking goes through this function.
create function track_order(p_no text,p_phone text) returns table(status text,total numeric) language sql security definer as $$select status,total from orders where order_no=p_no and phone=p_phone$$;
-- Insert your admin: insert into admins values('<auth user uuid>');
